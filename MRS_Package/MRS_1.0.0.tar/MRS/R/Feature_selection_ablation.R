#' Optional Feature Selection via Ablation Study with Fold-Level Metrics
#'
#' This function performs optional feature selection through systematic ablation analysis.
#' For each feature, it evaluates the model performance after removing that feature,
#' and compares it against the baseline model trained with all features.
#'
#' Performance metrics include AUC, AUPRC, F1-score, and Matthews Correlation Coefficient (MCC).
#' Fold-level results are also returned for visualization. Features that do not cause a performance
#' drop exceeding user-defined thresholds are removed.
#'
#' @details
#' This step is optional and intended for users who wish to reduce feature space based on performance contribution.
#' It is recommended to perform feature selection only after identifying the best model using full features.
#'
#' All metrics are calculated using predictions from internal cross-validation.
#' Fold-level results can be used to visualize error bars and variability across CV splits.
#'
#' @param prepared_data A list from \code{prepare_model_data()}, containing training and test sets and feature column names.
#' @param model_name The model to use for ablation (e.g., \code{"XGBoost"}).
#' @param threshold_auc Minimum AUC drop to retain a feature (default = 0.01).
#' @param threshold_auprc Minimum AUPRC drop to retain a feature (default = 0.01).
#' @param threshold_f1 Minimum F1 drop to retain a feature (default = 0.01).
#' @param threshold_mcc Minimum MCC drop to retain a feature (default = 0.01).
#' @param n_folds Number of cross-validation folds (default = 10).
#' @param n_repeats Number of CV repeats (default = 1).
#' @param seed Random seed for reproducibility (default = 123).
#' @param sampling Sampling strategy (e.g., \code{"up"}, \code{"down"}, or \code{"smote"}).
#' @param parallel Logical. Whether to use parallel computation (default = TRUE).
#' @param n_cores Integer. Number of CPU cores to use in parallel (default = 4).
#' @param center Logical. Whether to apply feature centering (default = TRUE).
#' @param scale Logical. Whether to apply feature scaling (default = TRUE).
#'
#' @return A list containing:
#' \describe{
#'   \item{baseline_metrics}{Model performance using all features.}
#'   \item{feature_results}{Data frame summarizing impact of removing each feature.}
#'   \item{selected_features}{Character vector of retained feature names.}
#'   \item{trainData}{Training set containing only selected features.}
#'   \item{testData}{Test set containing only selected features.}
#'   \item{per_fold_metrics}{Fold-wise metrics for each ablation iteration.}
#' }
#'
#' @examples
#' \dontrun{
#' # Simulated example dataset
#' data <- data.table::data.table(
#'   Label = sample(0:1, 100, replace = TRUE),
#'   X1 = rnorm(100),
#'   X2 = rnorm(100),
#'   X3 = runif(100)
#' )
#'
#' # Prepare data
#' prep <- Prepare_classification_data(data)
#'
#' # Run feature ablation using XGBoost (optional step)
#' fs_result <- Feature_selection_ablation(
#'   prepared_data = prep,
#'   model_name = "XGBoost",
#'   threshold_auc = 0.01,
#'   threshold_auprc = 0.01,
#'   threshold_f1 = 0.01,
#'   threshold_mcc = 0.01,
#'   n_folds = 5,
#'   n_repeats = 1,
#'   parallel = FALSE
#' )
#'
#' # View selected features
#' print(fs_result$selected_features)
#' }
#'
#' @seealso \code{\link[caret]{train}}, \code{\link[pROC]{roc}}, \code{\link[PRROC]{pr.curve}}
#'
#' @export
Feature_selection_ablation <- function(prepared_data,
                                       model_name = "XGBoost",
                                       threshold_auc = 0.01,
                                       threshold_auprc = 0.01,
                                       threshold_f1 = 0.01,
                                       threshold_mcc = 0.01,
                                       n_folds = 10, n_repeats = 1, seed = 123,
                                       sampling = "up", parallel = TRUE, n_cores = 4,
                                       center = TRUE, scale = TRUE) {
  set.seed(seed)

  if (parallel) {
    if (!requireNamespace("doParallel", quietly = TRUE)) stop("Please install 'doParallel'")
    if (is.null(n_cores)) n_cores <- parallel::detectCores() - 1
    cl <- parallel::makeCluster(n_cores)
    doParallel::registerDoParallel(cl)
    on.exit(parallel::stopCluster(cl), add = TRUE)
  }

  train_data <- prepared_data$trainData
  test_data <- prepared_data$testData
  feature_cols <- prepared_data$feature_cols

  model_map <- list(
    "LDA" = "lda", "CART" = "rpart", "Random Forest" = "rf",
    "GBM" = "gbm", "Naive Bayes" = "naive_bayes", "SVM" = "svmRadial",
    "KNN" = "knn", "Logistic Regression" = "glm", "NNET" = "nnet",
    "XGBoost" = "xgbTree"
  )

  if (!(model_name %in% names(model_map))) {
    stop("Unsupported model_name. Choose from: ", paste(names(model_map), collapse = ", "))
  }

  caret_method <- model_map[[model_name]]

  evaluate_model <- function(train_data) {
    tryCatch({
      if (!is.factor(train_data$Label)) {
        train_data$Label <- factor(train_data$Label, levels = c("neg", "pos"))
      }

      ctrl <- caret::trainControl(
        method = "repeatedcv", number = n_folds, repeats = n_repeats,
        classProbs = TRUE, summaryFunction = caret::twoClassSummary,
        savePredictions = "final", sampling = sampling,
        verboseIter = FALSE, allowParallel = parallel
      )

      model_args <- list()
      if (caret_method == "xgbTree") {
        model_args <- list(verbosity = 0, nthread = 1)
      }

      pre_methods <- c()
      if (center) pre_methods <- c(pre_methods, "center")
      if (scale) pre_methods <- c(pre_methods, "scale")

      model <- suppressWarnings(do.call(caret::train, c(
        list(
          x = train_data[, setdiff(names(train_data), "Label")],
          y = train_data$Label,
          method = caret_method,
          metric = "ROC",
          trControl = ctrl,
          preProcess = pre_methods
        ), model_args)))

      preds <- model$pred

      # === Feature evaluation based on overall predictions ===
      roc_obj <- pROC::roc(preds$obs, preds$pos, quiet = TRUE)
      auc_val <- as.numeric(pROC::auc(roc_obj))

      pos_probs <- preds[preds$obs == "pos", "pos"]
      neg_probs <- preds[preds$obs == "neg", "pos"]
      auprc_val <- if (length(pos_probs) > 0 && length(neg_probs) > 0) {
        PRROC::pr.curve(scores.class0 = pos_probs, scores.class1 = neg_probs, curve = FALSE)$auc.integral
      } else NA

      cm <- caret::confusionMatrix(preds$pred, preds$obs, positive = "pos")
      f1_val <- cm$byClass["F1"]

      TP <- cm$table["pos", "pos"]
      TN <- cm$table["neg", "neg"]
      FP <- cm$table["pos", "neg"]
      FN <- cm$table["neg", "pos"]
      mcc_val <- ifelse((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN) == 0, 0,
                        ((TP * TN) - (FP * FN)) / sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN)))
      # ====================================================================

      # === Per-fold results for plotting (AUPRC fixed) ===
      per_fold_df <- data.frame()
      for (fold in unique(preds$Resample)) {
        fold_pred <- preds[preds$Resample == fold, ]
        roc_f <- pROC::roc(fold_pred$obs, fold_pred$pos, quiet = TRUE)
        auc_f <- as.numeric(pROC::auc(roc_f))
        pos_f <- fold_pred[fold_pred$obs == "pos", "pos"]
        neg_f <- fold_pred[fold_pred$obs == "neg", "pos"]
        auprc_f <- if (length(pos_f) > 0 && length(neg_f) > 0) {
          PRROC::pr.curve(scores.class0 = pos_f, scores.class1 = neg_f, curve = FALSE)$auc.integral
        } else NA
        cm_f <- caret::confusionMatrix(fold_pred$pred, fold_pred$obs, positive = "pos")
        f1_f <- cm_f$byClass["F1"]
        TPf <- cm_f$table["pos", "pos"]
        TNf <- cm_f$table["neg", "neg"]
        FPf <- cm_f$table["pos", "neg"]
        FNf <- cm_f$table["neg", "pos"]
        mcc_f <- ifelse((TPf + FPf) * (TPf + FNf) * (TNf + FPf) * (TNf + FNf) == 0, 0,
                        ((TPf * TNf) - (FPf * FNf)) / sqrt((TPf + FPf) * (TPf + FNf) * (TNf + FPf) * (TNf + FNf)))
        per_fold_df <- rbind(per_fold_df, data.frame(Fold = fold, AUC = auc_f, AUPRC = auprc_f, F1 = f1_f, MCC = mcc_f))
      }
      # ====================================================================

      return(list(
        mean = setNames(c(auc_val, auprc_val, f1_val, mcc_val), c("AUC", "AUPRC", "F1", "MCC")),
        folds = per_fold_df
      ))
    }, error = function(e) {
      list(mean = setNames(rep(NA, 4), c("AUC", "AUPRC", "F1", "MCC")), folds = data.frame())
    })
  }

  # === Baseline evaluation ===
  base_eval <- evaluate_model(train_data)
  base_metrics <- base_eval$mean

  feature_results <- data.frame()
  retained_features <- feature_cols
  per_feature_fold_metrics <- list()

  pb <- txtProgressBar(min = 0, max = length(feature_cols), style = 3)

  for (feat in feature_cols) {
    mod_data <- train_data[, setdiff(names(train_data), feat)]
    eval_result <- evaluate_model(mod_data)
    metrics <- eval_result$mean
    per_feature_fold_metrics[[feat]] <- eval_result$folds

    delta <- base_metrics - metrics

    importance <- c(
      AUC = !is.na(delta["AUC"]) && delta["AUC"] >= threshold_auc,
      AUPRC = !is.na(delta["AUPRC"]) && delta["AUPRC"] >= threshold_auprc,
      F1 = !is.na(delta["F1"]) && delta["F1"] >= threshold_f1,
      MCC = !is.na(delta["MCC"]) && delta["MCC"] >= threshold_mcc
    )

    if (!any(importance)) {
      retained_features <- setdiff(retained_features, feat)
    }

    feature_results <- rbind(feature_results, data.frame(
      Feature = feat,
      AUC = round(metrics["AUC"], 3),
      AUPRC = round(metrics["AUPRC"], 3),
      F1 = round(metrics["F1"], 3),
      MCC = round(metrics["MCC"], 3),
      Delta_AUC = round(delta["AUC"], 3),
      Delta_AUPRC = round(delta["AUPRC"], 3),
      Delta_F1 = round(delta["F1"], 3),
      Delta_MCC = round(delta["MCC"], 3),
      Retained = any(importance),
      stringsAsFactors = FALSE
    ))

    setTxtProgressBar(pb, which(feature_cols == feat))
  }

  close(pb)

  train_selected <- train_data[, c(retained_features, "Label")]
  test_selected <- test_data[, c(retained_features, "Label")]

  return(list(
    baseline_metrics = round(base_metrics, 3),
    feature_results = feature_results,
    selected_features = retained_features,
    trainData = train_selected,
    testData = test_selected,
    per_fold_metrics = per_feature_fold_metrics
  ))
}
