#' Plot ROC Curves for Training Folds and Independent Test Set
#'
#' This function visualizes Receiver Operating Characteristic (ROC) curves for both
#' training (cross-validation folds) and independent test set. It interpolates
#' true positive rates (TPR) across a fixed grid of false positive rates (FPR),
#' allowing consistent comparison across folds.
#'
#' Training folds are visualized individually along with the average ROC curve and its
#' mean AUC ± standard deviation. The test ROC curve is shown with annotated AUC and
#' 95% confidence interval.
#'
#' @details
#' - Uses interpolation via \code{pROC::coords()} to standardize ROC curves across folds.
#' - Mean ± SD AUC is displayed for training; AUC with 95% CI is shown for test.
#' - Includes diagonal reference line and is formatted for publication using \code{ggplot2} and \code{patchwork}.
#'
#' @param train_roc_list A list of \code{pROC::roc} objects for each training fold (e.g., from \code{Tune_model_eval()}).
#' @param test_roc A \code{pROC::roc} object for the independent test set (e.g., from \code{Tune_model_eval()})..
#' @param title Title for the combined ROC curve plot (default: "ROC Curves").
#'
#' @return A \code{ggplot2} object displaying two panels:
#' \itemize{
#'   \item Left: Training ROC curves per fold and the average ROC.
#'   \item Right: Final model ROC curve on the test set.
#' }
#'
#' @examples
#' \dontrun{
#' # Assume model was tuned with Tune_model_eval()
#' train_roc_list <- result$train_roc_list
#' test_roc <- result$test_roc
#'
#' Plot_roc_curves(train_roc_list, test_roc, title = "Model ROC Comparison")
#' }
#'
#' @seealso \code{\link[pROC]{roc}}, \code{\link[patchwork]{plot_layout}}
#'
#' @export
Plot_roc_curves <- function(train_roc_list, test_roc, title = "ROC Curves") {
  fpr_vals <- seq(0, 1, length.out = 100)

  # ---- Train ROC: Per-fold ----
  train_interp <- sapply(train_roc_list, function(roc_obj) {
    pROC::coords(roc_obj, x = fpr_vals, input = "fpr", ret = "tpr", transpose = FALSE)
  })

  train_interp <- matrix(unlist(train_interp), ncol = length(train_roc_list))

  # Mean and SD
  mean_tpr <- rowMeans(train_interp, na.rm = TRUE)
  sd_tpr <- apply(train_interp, 1, sd, na.rm = TRUE)

  # Per-fold Data
  train_folds_df <- do.call(rbind, lapply(seq_along(train_roc_list), function(i) {
    data.frame(FPR = fpr_vals, TPR = train_interp[, i], Fold = paste0("Fold", i))
  }))

  # Mean line
  mean_df <- data.frame(FPR = fpr_vals, TPR = mean_tpr)

  # AUCs for train folds
  auc_vals <- sapply(train_roc_list, function(roc_obj) as.numeric(auc(roc_obj)))
  auc_mean <- mean(auc_vals, na.rm = TRUE)
  auc_sd <- sd(auc_vals, na.rm = TRUE)
  auc_text <- sprintf("AUC = %.3f ± %.3f", auc_mean, auc_sd)

  # ---- Test Set ----
  test_coords <- tryCatch({
    pROC::coords(test_roc, x = fpr_vals, input = "fpr", ret = "tpr", transpose = FALSE)
  }, error = function(e) rep(NA, length(fpr_vals)))

  if (is.matrix(test_coords)) {
    test_coords <- as.vector(test_coords[,1])
  } else if (is.data.frame(test_coords)) {
    test_coords <- as.vector(test_coords[[1]])
  }

  test_df <- data.frame(FPR = fpr_vals, TPR = test_coords)


  test_auc_ci <- ci.auc(test_roc)
  test_auc_text <- sprintf("AUC = %.3f [%.3f–%.3f]", auc(test_roc), test_auc_ci[1], test_auc_ci[3])

  # ---- Plot: Train ----
  p_train <- ggplot() +
    geom_line(data = train_folds_df, aes(x = FPR, y = TPR, group = Fold),
              color = "gray70", alpha = 0.7, size = 0.7) +
    geom_line(data = mean_df, aes(x = FPR, y = TPR),
              color = "#D77071", size = 1.2) +
    annotate("text", x = 0.2, y = 0.2, label = auc_text, size = 4.5, hjust = 0) +
    labs(title = "Train ROC (10-fold CV)", y = "True Positive Rate", x = "False Positive Rate") +
    theme_article(base_size = 12) +
    coord_equal()+geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey40")

  # ---- Plot: Test ----
  p_test <- ggplot(test_df, aes(x = FPR, y = TPR)) +
    geom_line(color = "#6888F5", size = 1.2) +
    annotate("text", x = 0.2, y = 0.2, label = test_auc_text, size = 4.5, hjust = 0) +
    labs(title = "Test ROC (Final Model)", y = "True Positive Rate", x = "False Positive Rate") +
    theme_article(base_size = 12) +
    coord_equal()+geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey40")

  # Combine plots
  combined <- p_train + p_test + plot_layout(ncol = 2) +
    plot_annotation(title = title)

  return(combined)
}
