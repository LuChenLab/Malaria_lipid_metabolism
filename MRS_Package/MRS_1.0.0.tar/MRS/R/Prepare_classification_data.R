#' Prepare Classification Data: Feature Encoding and Stratified Train-Test Split
#'
#' This function prepares labeled data for binary classification tasks.
#' It ensures all feature columns are numeric, converts non-numeric columns to numeric when possible,
#' and splits the data into training and testing sets using stratified sampling based on the 'Label' column.
#'
#' The resulting data is formatted for use with most machine learning classifiers,
#' including balanced class representation and explicit feature column tracking.
#'
#' @details
#' - All features must be numeric. Non-numeric columns (e.g., character or factor) are automatically converted.
#'   If conversion fails, an error will be raised.
#' - The data split is stratified, meaning the class distribution in the training and test sets reflects the original dataset.
#'
#' This function is particularly useful in pipelines that follow reliable negative selection or other semi-supervised labeling steps.
#'
#' @param data A data.frame or data.table that includes a binary 'Label' column (values 0 and 1) and feature columns.
#' @param test_size A numeric value between 0 and 1 indicating the proportion of the dataset to use for testing (default = 0.3).
#' @param seed Integer. Random seed for reproducibility.
#'
#' @return A list containing:
#' \describe{
#'   \item{trainData}{Training set with 'Label' as a factor (levels: 'neg', 'pos').}
#'   \item{testData}{Test set with 'Label' as a factor (levels: 'neg', 'pos').}
#'   \item{feature_cols}{Character vector of column names used as features (excluding 'Label').}
#' }
#'
#' @examples
#' # Simulate labeled data
#' dt <- data.table::data.table(
#'   Label = sample(0:1, 100, replace = TRUE),
#'   Score1 = rnorm(100),
#'   Score2 = runif(100)
#' )
#'
#' # Prepare classification-ready data
#' out <- Prepare_classification_data(dt, test_size = 0.3, seed = 123)
#' str(out$trainData)
#'
#' @seealso \code{\link[caret]{createDataPartition}}, \code{\link[base]{as.numeric}}
#'
#' @export
Prepare_classification_data <- function(data, test_size = 0.3, seed = 123) {
  set.seed(seed)

  # Ensure Label column exists and is binary
  if (!"Label" %in% colnames(data)) {
    stop("Input data must contain a 'Label' column.")
  }
  if (!all(data$Label %in% c(0, 1))) {
    stop("Label column must contain only 0 and 1 values.")
  }

  pb <- txtProgressBar(min = 0, max = 2, style = 3)

  # Convert non-numeric features to numeric if possible
  for (col in setdiff(names(data), "Label")) {
    if (!is.numeric(data[[col]])) {
      tryCatch({
        data[[col]] <- as.numeric(as.character(data[[col]]))
      }, warning = function(w) {
        warning(sprintf("Column '%s' could not be safely converted to numeric.", col))
      }, error = function(e) {
        stop(sprintf("Column '%s' conversion to numeric failed.", col))
      })
    }
  }
  setTxtProgressBar(pb, 1)

  # Stratified split using caret
  idx <- caret::createDataPartition(data$Label, p = 1 - test_size, list = FALSE)
  trainData <- data[idx, ]
  testData <- data[-idx, ]

  # Convert Label to factor
  trainData$Label <- factor(trainData$Label, levels = c(0, 1), labels = c("neg", "pos"))
  testData$Label <- factor(testData$Label, levels = c(0, 1), labels = c("neg", "pos"))
  setTxtProgressBar(pb, 2)
  close(pb)

  # Get feature column names
  feature_cols <- setdiff(names(trainData), "Label")

  return(list(
    trainData = trainData,
    testData = testData,
    feature_cols = feature_cols
  ))
}
