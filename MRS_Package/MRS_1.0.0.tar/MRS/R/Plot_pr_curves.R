#' Plot Precision-Recall Curves for Training Folds and Independent Test Set
#'
#' This function visualizes precision-recall (PR) curves from cross-validation folds
#' and a held-out test set. It interpolates precision values across a fixed recall grid
#' to compute a mean PR curve for training folds and compares it with the test PR curve.
#'
#' It also annotates AUPRC (Area Under the PR Curve) values for both training and test data,
#' and uses a dual-panel layout for publication-ready comparison.
#'
#' @details
#' - Interpolation is performed using \code{stats::approx} on a shared recall grid (default 100 points).
#' - AUPRC mean ± SD is displayed for training data; test AUPRC is reported as a single value.
#' - Plot styling is handled by \code{ggplot2} and \code{patchwork}.
#'
#' This function is especially useful for comparing model generalization and stability across folds.
#'
#' @param train_pr_list A named list of \code{PRROC::pr.curve} objects for each training fold (e.g., from \code{Tune_model_eval()}).
#' @param test_pr A single \code{PRROC::pr.curve} object for the independent test set (e.g., from \code{Tune_model_eval()}).
#' @param title Optional title for the combined plot (default = "Precision-Recall Curves").
#'
#' @return A \code{ggplot} object displaying:
#' \itemize{
#'   \item Left panel: Per-fold training PR curves and the averaged mean curve.
#'   \item Right panel: PR curve for the test set.
#' }
#'
#' @examples
#' \dontrun{
#' # Assume model was tuned with Tune_model_eval()
#' train_pr_list <- result$train_pr_list
#' test_pr <- result$test_pr
#'
#' # Generate PR comparison plot
#' Plot_pr_curves(train_pr_list, test_pr, title = "Model PR Curve Comparison")
#' }
#'
#' @seealso \code{\link[PRROC]{pr.curve}}, \code{\link[patchwork]{plot_layout}}
#'
#' @import ggplot2
#' @import patchwork
#' @importFrom stats approx
#'
#' @export
Plot_pr_curves <- function(train_pr_list, test_pr, title = "Precision-Recall Curves") {
  # ---- Interpolation grid ----
  recall_vals <- seq(0, 1, length.out = 100)

  # ---- Training folds interpolation ----
  train_interp <- sapply(train_pr_list, function(pr_obj) {
    interp_prec <- approx(x = pr_obj$curve[, 1], y = pr_obj$curve[, 2],
                          xout = recall_vals, yleft = 1, yright = 0, ties = mean)$y
    return(interp_prec)
  })

  # Ensure matrix shape
  train_interp <- matrix(unlist(train_interp), ncol = length(train_pr_list))

  # Mean and SD
  train_mean_prec <- rowMeans(train_interp, na.rm = TRUE)
  train_sd_prec <- apply(train_interp, 1, sd, na.rm = TRUE)

  train_df <- data.frame(
    Recall = recall_vals,
    MeanPrec = train_mean_prec,
    SD_Prec = train_sd_prec,
    Upper = pmin(train_mean_prec + train_sd_prec, 1),
    Lower = pmax(train_mean_prec - train_sd_prec, 0)
  )

  # ---- Per fold PR curve data ----
  train_folds_df <- do.call(rbind, lapply(names(train_pr_list), function(fold_name) {
    curve_data <- train_pr_list[[fold_name]]$curve
    data.frame(Recall = curve_data[,1], Precision = curve_data[,2], Fold = fold_name)
  }))

  # AUPRC mean ± SD
  auprc_vals <- sapply(train_pr_list, function(pr) pr$auc.integral)
  auprc_mean <- mean(auprc_vals, na.rm = TRUE)
  auprc_sd <- sd(auprc_vals, na.rm = TRUE)
  auprc_text_train <- sprintf("AUPRC = %.3f ± %.3f", auprc_mean, auprc_sd)

  # ---- Test PR curve ----
  test_curve <- test_pr$curve
  test_df <- data.frame(Recall = test_curve[,1], Precision = test_curve[,2])
  auprc_test <- test_pr$auc.integral
  auprc_text_test <- sprintf("AUPRC = %.3f", auprc_test)

  # ---- Train PR plot ----
  p_train <- ggplot() +
    geom_line(data = train_folds_df, aes(x = Recall, y = Precision, group = Fold),
              color = "grey70", size = 0.6, alpha = 0.7) +
    geom_line(data = train_df, aes(x = Recall, y = MeanPrec),
              color = "#D77071", size = 1.2) +
    annotate("text", x = 0.2, y = 0.2, label = auprc_text_train, size = 4.5, hjust = 0) +
    labs(title = "Train PR Curve (10-fold CV)", x = "Recall", y = "Precision") +
    theme_article(base_size = 12) +
    coord_equal()

  # ---- Test PR plot ----
  p_test <- ggplot(test_df, aes(x = Recall, y = Precision)) +
    geom_line(color = "#6888F5", size = 1.2) +
    annotate("text", x = 0.2, y = 0.2, label = auprc_text_test, size = 4.5, hjust = 0) +
    labs(title = "Test PR Curve", x = "Recall", y = "Precision") +
    theme_article(base_size = 12) +
    coord_equal()

  # ---- Combine plots ----
  combined <- p_train + p_test + patchwork::plot_layout(ncol = 2) +
    patchwork::plot_annotation(title = title)

  return(combined)
}

