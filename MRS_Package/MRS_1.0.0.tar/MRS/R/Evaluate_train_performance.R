#' Evaluate Cross-Validation Performance of Trained Models
#'
#' This function evaluates multiple classification models trained using caret by extracting
#' their internal cross-validation predictions. It computes fold-wise and overall performance
#' metrics including AUC, AUPRC, F1-score, and Matthews Correlation Coefficient (MCC).
#'
#' The function returns summarized performance statistics, fold-level metrics, and the corresponding
#' ROC and precision-recall curves for each model. Models are ranked by average AUC.
#'
#' @details
#' This function does not evaluate models on a hold-out test set. Instead, it uses predictions
#' generated during internal cross-validation (via \code{trainControl(savePredictions = "final")}).
#' It supports robust evaluation of model stability and generalization during training.
#'
#' F1 and MCC are computed from fold-wise confusion matrices. PR curves use the \code{PRROC} package.
#'
#' @param trained_models A named list of models trained via \code{Train_multiple_models()}.
#' @param prepared_data A list returned from \code{Prepare_classification_data()},
#'                      which contains the test set (\code{testData}) and optionally training data.
#' @param seed Random seed for reproducibility (default = 123).
#'
#' @return A list with the following elements:
#' \describe{
#'   \item{train_results}{A data frame with model-level summary metrics (AUC, AUPRC, F1, MCC).}
#'   \item{per_fold_metrics}{A named list of data frames with per-fold metrics for each model.}
#'   \item{roc_curves}{A list of overall ROC curve objects (from \code{pROC::roc}) per model.}
#'   \item{pr_curves}{A list of overall PR curve objects (from \code{PRROC::pr.curve}) per model.}
#' }
#'
#' @examples
#' \dontrun{
#' prep <- Prepare_classification_data(my_data)
#' models <- Train_multiple_models(prep)
#' eval <- Evaluate_train_performance(models, prepared_data = prep)
#' print(eval$train_results)
#' }
#'
#' @seealso \code{\link[caret]{train}}, \code{\link[pROC]{roc}}, \code{\link[PRROC]{pr.curve}}
#'
#' @export
Evaluate_train_performance <- function(trained_models, prepared_data, seed = 123) {
  set.seed(seed)

  trainData_processed <- prepared_data$trainData

  train_results_summary <- data.frame()
  per_fold_metrics <- list()
  train_roc_curves <- list()
  train_pr_curves <- list()

  for (model_name in names(trained_models)) {
    model <- trained_models[[model_name]]
    fold_metrics <- data.frame(AUC = numeric(), AUPRC = numeric(), F1 = numeric(), MCC = numeric())
    fold_roc_list <- list()
    fold_pr_list <- list()

    if ("pred" %in% names(model) && nrow(model$pred) > 0) {
      for (fold in unique(model$pred$Resample)) {
        tryCatch({
          fold_pred <- model$pred[model$pred$Resample == fold, ]
          pos_samples <- sum(fold_pred$obs == "pos")
          neg_samples <- sum(fold_pred$obs == "neg")

          if (pos_samples > 0 && neg_samples > 0) {
            prob_cols <- grep("^pos$|^1$|^class1$", names(fold_pred), value = TRUE)
            if(length(prob_cols) > 0) {
              pos_prob_col <- prob_cols[1]
            } else if(model_name == "KNN" && "rowIndex" %in% names(fold_pred)) {
              pos_probs <- ifelse(fold_pred$pred == "pos", 0.9, 0.1)
              fold_pred$pos <- pos_probs
              pos_prob_col <- "pos"
            } else {
              pos_prob_col <- names(fold_pred)[ncol(fold_pred) - 1]
            }

            pr_obj <- pr.curve(
              scores.class0 = fold_pred[fold_pred$obs == "pos", pos_prob_col],
              scores.class1 = fold_pred[fold_pred$obs == "neg", pos_prob_col],
              curve = TRUE
            )
            fold_pr_list[[fold]] <- pr_obj

            pred_classes <- factor(fold_pred$pred, levels = c("neg", "pos"))
            cm <- confusionMatrix(pred_classes, fold_pred$obs, positive = "pos")
            fold_f1 <- cm$byClass["F1"]

            TP <- cm$table["pos", "pos"]
            TN <- cm$table["neg", "neg"]
            FP <- cm$table["neg", "pos"]
            FN <- cm$table["pos", "neg"]
            numerator <- (TP * TN) - (FP * FN)
            denominator <- sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN))
            fold_mcc <- ifelse(denominator == 0, NA, numerator / denominator)

            fold_roc <- roc(fold_pred$obs, fold_pred[[pos_prob_col]], quiet = TRUE)
            fold_roc_list[[fold]] <- fold_roc
            fold_auc <- as.numeric(fold_roc$auc)

            fold_metrics <- rbind(fold_metrics, data.frame(
              Fold = fold,
              AUC = fold_auc,
              AUPRC = pr_obj$auc.integral,
              F1 = fold_f1,
              MCC = fold_mcc
            ))
          }
        }, error = function(e) {})
      }
    }

    per_fold_metrics[[model_name]] <- fold_metrics

    tryCatch({
      if("pred" %in% names(model) && nrow(model$pred) > 0) {
        all_preds <- model$pred
        prob_cols <- grep("^pos$|^1$|^class1$", names(all_preds), value = TRUE)
        if(length(prob_cols) > 0) {
          pos_prob_col <- prob_cols[1]
        } else if(model_name == "KNN") {
          pos_probs <- ifelse(all_preds$pred == "pos", 0.9, 0.1)
          all_preds$pos <- pos_probs
          pos_prob_col <- "pos"
        } else {
          pos_prob_col <- names(all_preds)[ncol(all_preds) - 1]
        }

        train_roc_curves[[model_name]] <- roc(all_preds$obs, all_preds[[pos_prob_col]], quiet = TRUE)
        train_pr_curves[[model_name]] <- pr.curve(
          scores.class0 = all_preds[all_preds$obs == "pos", pos_prob_col],
          scores.class1 = all_preds[all_preds$obs == "neg", pos_prob_col],
          curve = TRUE
        )
      }
    }, error = function(e) {})

    train_auc_mean <- ifelse(nrow(fold_metrics) > 0, mean(fold_metrics$AUC, na.rm = TRUE), NA)
    train_auc_sd <- ifelse(nrow(fold_metrics) > 0, sd(fold_metrics$AUC, na.rm = TRUE), NA)
    train_auprc_mean <- ifelse(nrow(fold_metrics) > 0, mean(fold_metrics$AUPRC, na.rm = TRUE), NA)
    train_auprc_sd <- ifelse(nrow(fold_metrics) > 0, sd(fold_metrics$AUPRC, na.rm = TRUE), NA)
    train_f1_mean <- ifelse(nrow(fold_metrics) > 0, mean(fold_metrics$F1, na.rm = TRUE), NA)
    train_f1_sd <- ifelse(nrow(fold_metrics) > 0, sd(fold_metrics$F1, na.rm = TRUE), NA)
    train_mcc_mean <- ifelse(nrow(fold_metrics) > 0, mean(fold_metrics$MCC, na.rm = TRUE), NA)
    train_mcc_sd <- ifelse(nrow(fold_metrics) > 0, sd(fold_metrics$MCC, na.rm = TRUE), NA)

    train_results_summary <- rbind(train_results_summary, data.frame(
      Model = model_name,
      AUC = sprintf("%.3f ± %.3f", train_auc_mean, train_auc_sd),
      AUPRC = sprintf("%.3f ± %.3f", train_auprc_mean, train_auprc_sd),
      F1 = sprintf("%.3f ± %.3f", train_f1_mean, train_f1_sd),
      MCC = sprintf("%.3f ± %.3f", train_mcc_mean, train_mcc_sd),
      AUC_Value = train_auc_mean,
      stringsAsFactors = FALSE
    ))
  }

  if (nrow(train_results_summary) == 0) {
    warning("No models were successfully evaluated on training set")
    return(NULL)
  }

  train_results_summary <- train_results_summary[order(train_results_summary$AUC_Value, decreasing = TRUE), ]
  train_results_summary$AUC_Value <- NULL

  # === Only print final ranking ===
  cat("\nTraining Set Model Performance Ranking (by AUC):\n")
  for (i in 1:nrow(train_results_summary)) {
    cat(sprintf("%d. %s: AUC=%s, AUPRC=%s, F1=%s, MCC=%s\n",
                i,
                train_results_summary$Model[i],
                train_results_summary$AUC[i],
                train_results_summary$AUPRC[i],
                train_results_summary$F1[i],
                train_results_summary$MCC[i]))
  }

  return(list(
    train_results = train_results_summary,
    per_fold_metrics = per_fold_metrics,
    roc_curves = train_roc_curves,
    pr_curves = train_pr_curves
  ))
}
