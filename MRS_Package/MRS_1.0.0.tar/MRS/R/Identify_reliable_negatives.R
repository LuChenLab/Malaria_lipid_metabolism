#' Identify Reliable Negatives via Spy PU-Learning
#'
#' This function performs positive-unlabeled (PU) learning using the Spy technique
#' to identify a reliable set of negative samples from unlabeled data. Only samples
#' with \code{Label == 1} are treated as known positives; all others are considered
#' unlabeled. A portion of the positives are temporarily relabeled as "spies" and
#' used to train a Naive Bayes model alongside the unlabeled data.
#'
#' Based on the predicted probability distribution of the spies, the function selects
#' unlabeled samples with low probability of being positive as reliable negatives. The
#' final output is a binary-labeled dataset combining the original positives and the
#' selected reliable negatives.
#'
#' @details
#' This function implements the Spy PU-learning algorithm, originally proposed by Liu et al. (2003),
#' where a small subset of the known positives (spies) are inserted into the unlabeled set to estimate
#' the negative class distribution. A Naive Bayes classifier is trained to identify unlabeled samples
#' with low posterior probability of being positive, which are treated as reliable negatives.
#'
#' All input features must be numeric. If the dataset contains categorical variables (e.g., factor or character),
#' they should be encoded into numeric form (e.g., via one-hot encoding) before applying this function.
#'
#' For more information on the Spy PU-learning method, see:
#' https://github.com/trokas/pu_learning
#'
#' @references
#' Liu, B., Dai, Y., Li, X., Lee, W. S., & Yu, P. S. (2003).
#' Building text classifiers using positive and unlabeled examples.
#' In *Proceedings of the Third IEEE International Conference on Data Mining* (pp. 179–186).
#' IEEE. \doi{10.1109/ICDM.2003.1250918}
#'
#' @param Feature A data.frame or data.table containing numeric feature columns and a 'Label' column.
#'                Only rows with \code{Label == 1} are treated as positive samples. All others are considered unlabeled.
#' @param spy_ratio Proportion of positive samples to be used as spies (e.g., 0.3).
#'                  Must be between 0 and 1, and strictly less than 1.
#' @param threshold_quantile Quantile threshold for selecting reliable negatives from the unlabeled pool (e.g., 0.05).
#' @param seed Integer. Random seed for reproducibility.
#'
#' @return A data.table with numeric features and a binary factor column \code{Label},
#'         where \code{1} indicates positive and \code{0} indicates reliably predicted negative.
#'
#' @examples
#' # Simulate mixed dataset with 5 features and labels
#' dt <- data.table::data.table(
#'   Label = c(rep(1, 10), rep(0, 90), rep(2, 10)),
#'   matrix(rnorm(110 * 5), ncol = 5)
#' )
#'
#' # Apply Spy PU-learning to identify reliable negatives
#' result <- Identify_reliable_negatives(dt, spy_ratio = 0.3, threshold_quantile = 0.05)
#' table(result$Label)
#'
#' @seealso \code{\link[e1071]{naiveBayes}}, \code{\link[base]{quantile}}, \code{\link[stats]{predict}}
#'
#' @export
Identify_reliable_negatives <- function(Feature, spy_ratio = 0.3, threshold_quantile = 0.05, seed = 123) {
  set.seed(seed)

  # Ensure data.table
  if (!data.table::is.data.table(Feature)) {
    Feature <- data.table::as.data.table(Feature)
  }

  # Check Label column exists
  if (!"Label" %in% colnames(Feature)) {
    stop("Input data must contain a 'Label' column.")
  }

  # Split positive and unlabeled: only Label == 1 is treated as positive
  p <- Feature[Label == 1, -c("Label"), with = FALSE]
  u <- Feature[Label != 1, -c("Label"), with = FALSE]

  if (nrow(p) < 2) stop("Positive set too small for PU-learning.")

  # Validate spy_ratio
  n_spy <- round(nrow(p) * spy_ratio)
  if (n_spy == 0 || n_spy >= nrow(p)) {
    stop("Invalid spy_ratio: spy set or remaining positive set is empty.")
  }

  # Progress bar
  pb <- txtProgressBar(min = 0, max = 3, style = 3)

  # Step 1: Spy sampling
  spy_idx <- sample(seq_len(nrow(p)), n_spy)
  s <- p[spy_idx, ]
  ps <- p[-spy_idx, ]
  ps$Label_new <- 1
  setTxtProgressBar(pb, 1)

  # Step 2: Train Naive Bayes
  us <- rbind(u, s)
  us$Label_new <- -1
  train_data <- rbind(ps, us)
  nb_model <- e1071::naiveBayes(as.factor(Label_new) ~ ., data = train_data)
  setTxtProgressBar(pb, 2)

  # Step 3: Predict and select reliable negatives
  spy_pred <- predict(nb_model, s, type = "raw")
  if (!"1" %in% colnames(spy_pred)) {
    warning("Naive Bayes output does not contain class '1'. Returning input data.")
    Feature$Label <- factor(ifelse(Feature$Label == 1, 1, 0), levels = c(0, 1))
    close(pb)
    return(Feature)
  }
  pos_col <- which(colnames(spy_pred) == "1")
  threshold_val <- quantile(spy_pred[, pos_col], probs = threshold_quantile)

  u_pred <- predict(nb_model, u, type = "raw")
  if (!"1" %in% colnames(u_pred)) {
    warning("Prediction does not contain class '1'. Returning only positives.")
    close(pb)
    p$Label <- 1
    return(p)
  }

  index_rn <- which(u_pred[, pos_col] < threshold_val)
  setTxtProgressBar(pb, 3)
  close(pb)

  if (length(index_rn) == 0) {
    warning("No reliable negatives found. Returning only positives.")
    p$Label <- 1
    return(p)
  }

  # Construct final dataset
  u_reliable <- u[index_rn, ]
  u_reliable$Label <- 0
  p$Label <- 1
  NewData <- rbind(p, u_reliable)
  NewData$Label <- factor(NewData$Label, levels = c(0, 1))

  return(NewData)
}
