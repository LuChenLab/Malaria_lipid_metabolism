#' Parameter Tuning for Spy PU-Learning using Naive Bayes and Logistic Regression
#'
#' This function performs parameter tuning for Spy-based positive-unlabeled (PU) learning.
#' It searches over a grid of spy ratios and probability thresholds to identify the optimal
#' combination for selecting reliable negative samples from unlabeled data.
#'
#' For each parameter combination, the function performs multiple repeats. In each repeat,
#' a subset of the positive samples is randomly assigned as "spies", and a Naive Bayes classifier
#' is trained to estimate the posterior probability of class membership. Based on the predicted
#' probabilities, reliable negatives are selected from the unlabeled set. The resulting labeled
#' data (positives + reliable negatives) is evaluated using logistic regression with cross-validation.
#'
#' @details
#' Spy PU-learning is a semi-supervised strategy where a small proportion of known positives (spies) are
#' inserted into the unlabeled set to estimate the distribution of the negative class. This function
#' automates the search for optimal spy ratio and threshold values by evaluating the resulting
#' pseudo-labeled dataset with logistic regression and reporting average performance across repeats.
#'
#' All input features must be numeric. If the dataset contains categorical variables (e.g., factor or character),
#' they should be encoded into numeric form (e.g., via one-hot encoding) before applying this function.
#'
#' For more information on the Spy PU-learning method, see:
#' https://github.com/trokas/pu_learning
#'
#' @references
#' Liu, B., Dai, Y., Li, X., Lee, W. S., & Yu, P. S. (2003).
#' Building text classifiers using positive and unlabeled examples.
#' In *Proceedings of the Third IEEE International Conference on Data Mining* (pp. 179–186).
#' IEEE. \doi{10.1109/ICDM.2003.1250918}
#'
#' @param p_data A data frame of positive samples. All columns must be numeric and contain no missing values.
#' @param u_data A data frame of unlabeled samples with the same structure as \code{p_data}.
#' @param pu_repeats Integer. Number of repeats per parameter combination (default = 10).
#' @param cv_folds Integer. Number of cross-validation folds for performance evaluation (default = 3).
#' @param seed Integer. Random seed for reproducibility.
#'
#' @return A data frame summarizing performance metrics (AUC, AUPRC, F1, MCC) and their standard deviations
#'         for each combination of spy ratio and probability threshold.
#'
#' @examples
#' # Simulate positive and unlabeled data
#' set.seed(42)
#' p_data <- as.data.frame(matrix(rnorm(50), nrow = 10))
#' u_data <- as.data.frame(matrix(rnorm(500), nrow = 100))
#'
#' # Run tuning
#' result <- Tune_spy_pu(p_data, u_data, pu_repeats = 10, cv_folds = 3)
#' head(result)
#'
#' @seealso \code{\link[e1071]{naiveBayes}}, \code{\link[caret]{train}}, \code{\link[pROC]{roc}}, \code{\link[PRROC]{pr.curve}}
#'
#' @export
Tune_spy_pu <- function(p_data, u_data, pu_repeats = 10, cv_folds = 3, seed = 123) {
  set.seed(seed)

  # Define grid of spy ratios and threshold quantiles
  spy_ratios <- c(0.10, 0.15, 0.20, 0.25, 0.30)
  thresholds <- c(0.05, 0.10, 0.15, 0.20, 0.25)
  param_grid <- expand.grid(spy_ratio = spy_ratios, threshold = thresholds)

  results <- data.frame()
  pb <- txtProgressBar(min = 0, max = nrow(param_grid), style = 3)

  for (i in 1:nrow(param_grid)) {
    spy_ratio <- param_grid$spy_ratio[i]
    threshold_q <- param_grid$threshold[i]

    auc_vals <- auprc_vals <- f1_vals <- mcc_vals <- c()

    for (r in 1:pu_repeats) {
      # Generate repeat-specific seed
      safe_seed <- as.integer((seed + i * 100 + r) %% 1e6)
      set.seed(safe_seed)

      # Split positive data into spies and true positives
      spy_n <- round(nrow(p_data) * spy_ratio)
      spy_idx <- sample(seq_len(nrow(p_data)), spy_n)
      s <- p_data[spy_idx, ]
      ps <- p_data[-spy_idx, ]
      if (nrow(ps) == 0 || nrow(s) == 0) next

      # Assign temporary PU labels
      ps$Label_new <- 1
      s$Label_new <- -1
      u_data_tmp <- u_data
      u_data_tmp$Label_new <- -1

      # Combine training data
      train_data <- rbind(ps, s, u_data_tmp)

      # Train Naive Bayes to estimate class probabilities
      nb_model <- e1071::naiveBayes(as.factor(Label_new) ~ ., data = train_data)

      # Predict probabilities for spies and check if class "1" exists
      spy_pred <- predict(nb_model, s, type = "raw")
      if (!"1" %in% colnames(spy_pred)) next
      spy_probs <- spy_pred[, "1"]
      threshold_val <- quantile(spy_probs, probs = threshold_q)

      # Predict probabilities for unlabeled data
      u_pred <- predict(nb_model, u_data, type = "raw")
      if (!"1" %in% colnames(u_pred)) next
      u_probs <- u_pred[, "1"]
      reliable_idx <- which(u_probs < threshold_val)
      if (length(reliable_idx) == 0) next

      # Prepare labeled dataset with positive and reliable negatives
      rn <- u_data[reliable_idx, ]
      rn$Label <- 0
      p_all <- p_data
      p_all$Label <- 1
      labeled_data <- rbind(p_all, rn)
      labeled_data$Label <- factor(labeled_data$Label, levels = c(0, 1), labels = c("neg", "pos"))

      # Skip training if only one class is present
      if (length(unique(labeled_data$Label)) < 2) next

      # Train logistic regression with cross-validation
      ctrl <- caret::trainControl(
        method = "cv",
        number = cv_folds,
        classProbs = TRUE,
        summaryFunction = twoClassSummary,
        savePredictions = "final",
        allowParallel = FALSE,
        verboseIter = FALSE
      )

      model <- tryCatch({
        suppressWarnings(
          caret::train(
            Label ~ .,
            data = labeled_data,
            method = "glm",
            family = "binomial",
            trControl = ctrl,
            preProcess = c("center", "scale"),
            metric = "ROC"
          )
        )
      }, error = function(e) NULL)

      # Collect evaluation metrics if model was trained successfully
      if (!is.null(model) && "pred" %in% names(model)) {
        pred_df <- model$pred

        roc_obj <- pROC::roc(response = pred_df$obs, predictor = pred_df$pos, quiet = TRUE)
        fold_auc <- pROC::auc(roc_obj)

        pos_probs <- pred_df[pred_df$obs == "pos", "pos"]
        neg_probs <- pred_df[pred_df$obs == "neg", "pos"]
        pr_obj <- PRROC::pr.curve(scores.class0 = pos_probs, scores.class1 = neg_probs, curve = FALSE)
        fold_auprc <- pr_obj$auc.integral

        cm <- caret::confusionMatrix(pred_df$pred, pred_df$obs, positive = "pos")
        fold_f1 <- cm$byClass["F1"]

        # Compute Matthews Correlation Coefficient (MCC)
        TP <- as.numeric(cm$table["pos", "pos"])
        TN <- as.numeric(cm$table["neg", "neg"])
        FP <- as.numeric(cm$table["neg", "pos"])
        FN <- as.numeric(cm$table["pos", "neg"])
        numerator <- (TP * TN) - (FP * FN)
        denominator <- sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN))
        fold_mcc <- ifelse(denominator == 0, NA, numerator / denominator)

        auc_vals <- c(auc_vals, as.numeric(fold_auc))
        auprc_vals <- c(auprc_vals, as.numeric(fold_auprc))
        f1_vals <- c(f1_vals, as.numeric(fold_f1))
        mcc_vals <- c(mcc_vals, as.numeric(fold_mcc))
      }
    }

    # Store mean metrics across repeats for current parameter combination
    if (length(auc_vals) > 0) {
      results <- rbind(results, data.frame(
        spy_ratio = spy_ratio,
        threshold = threshold_q,
        AUC = round(mean(auc_vals, na.rm = TRUE), 3),
        AUC_SD = round(sd(auc_vals, na.rm = TRUE), 3),
        AUPRC = round(mean(auprc_vals, na.rm = TRUE), 3),
        AUPRC_SD = round(sd(auprc_vals, na.rm = TRUE), 3),
        F1 = round(mean(f1_vals, na.rm = TRUE), 3),
        F1_SD = round(sd(f1_vals, na.rm = TRUE), 3),
        MCC = round(mean(mcc_vals, na.rm = TRUE), 3),
        MCC_SD = round(sd(mcc_vals, na.rm = TRUE), 3)
      ))
    }

    setTxtProgressBar(pb, i)
  }

  close(pb)
  return(results)
}
