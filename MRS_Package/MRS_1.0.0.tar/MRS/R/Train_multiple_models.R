#' Train and Compare Multiple Classification Models using caret
#'
#' This function trains a panel of machine learning models on a binary-labeled training set,
#' using the caret framework and repeated cross-validation. It supports configurable sampling strategies,
#' centering/scaling preprocessing, and optional parallel computation.
#'
#' The models include logistic regression, SVM, random forest, XGBoost, KNN, Naive Bayes, LDA, neural networks, and more.
#' The trained models can be used for downstream evaluation and prediction tasks.
#'
#' @details
#' This function compares multiple machine learning algorithms using the same cross-validation configuration.
#' Each model is evaluated using the ROC metric. The models are trained using caret's \code{train()} function
#' and can include preprocessing steps like centering and scaling.
#'
#' Parallel training is enabled using the \code{doParallel} backend.
#' Note that XGBoost and other models with internal threading may conflict with external cores.
#'
#' @param prepared_data A list returned from \code{prepare_model_data()} or \code{prepare_classification_data()},
#'                      containing \code{trainData} (with binary factor 'Label') and \code{feature_cols}.
#' @param n_folds Integer. Number of folds for cross-validation (default = 10).
#' @param n_repeats Integer. Number of repeats for cross-validation (default = 1).
#' @param parallel Logical. Whether to enable parallel training (default = TRUE).
#' @param n_cores Integer or NULL. Number of CPU cores to use if \code{parallel = TRUE}. Auto-detects if NULL.
#' @param seed Random seed for reproducibility.
#' @param sampling Optional resampling strategy. Options include \code{"up"}, \code{"down"}, \code{"smote"}, or \code{NULL}.
#' @param center Logical. Whether to apply feature centering (default = TRUE).
#' @param scale Logical. Whether to apply feature scaling (default = TRUE).
#'
#' @return A named list of trained \code{caret} model objects. Each model includes performance metrics, predictions,
#'         and fitted parameters, and can be used for evaluation or prediction.
#'
#' @examples
#' \dontrun{
#' # Simulate dataset
#' data <- data.table::data.table(
#'   Label = sample(0:1, 100, replace = TRUE),
#'   x1 = rnorm(100),
#'   x2 = runif(100)
#' )
#'
#' # Prepare training data
#' prep <- Prepare_classification_data(data)
#'
#' # Train and compare models
#' models <- Train_multiple_models(prepared_data = prep, n_folds = 10, parallel = FALSE)
#' names(models)
#' }
#'
#' @seealso \code{\link[caret]{train}}, \code{\link[caret]{trainControl}}, \code{\link[doParallel]{registerDoParallel}}
#'
#' @export
Train_multiple_models <- function(prepared_data,
                         n_folds = 10,
                         n_repeats = 1,
                         parallel = TRUE,
                         n_cores = NULL,
                         seed = 123,
                         sampling = "up",
                         center = TRUE,
                         scale = TRUE) {
  set.seed(seed)

  if (!is.list(prepared_data) || !"trainData" %in% names(prepared_data)) {
    stop("prepared_data must be a list returned by prepare_model_data()")
  }

  trainData_processed <- prepared_data$trainData
  feature_cols <- prepared_data$feature_cols

  if (!"Label" %in% colnames(trainData_processed)) {
    stop("trainData must contain a 'Label' column.")
  }

  # Helper: XGBoost seed list
  create_xgboost_seeds <- function(nfolds, nrepeats) {
    set.seed(seed)
    total_folds <- nfolds * nrepeats
    seeds <- vector("list", length = total_folds + 1)
    for (i in 1:total_folds) {
      seeds[[i]] <- sample.int(1000, 36)
    }
    seeds[[total_folds + 1]] <- sample.int(1000, 1)
    seeds
  }

  # Helper: regular models seed list
  create_regular_seeds <- function(nfolds, nrepeats, nmodels = 10) {
    set.seed(seed)
    total_folds <- nfolds * nrepeats
    seeds <- vector("list", length = total_folds + 1)
    for (i in 1:total_folds) {
      seeds[[i]] <- sample.int(1000, nmodels)
    }
    seeds[[total_folds + 1]] <- sample.int(1000, 1)
    seeds
  }

  # Caret controls
  regular_control <- caret::trainControl(
    method = "repeatedcv",
    number = n_folds,
    repeats = n_repeats,
    classProbs = TRUE,
    summaryFunction = caret::twoClassSummary,
    savePredictions = "final",
    sampling = sampling,
    verboseIter = TRUE,
    seeds = create_regular_seeds(n_folds, n_repeats)
  )

  xgboost_control <- caret::trainControl(
    method = "repeatedcv",
    number = n_folds,
    repeats = n_repeats,
    classProbs = TRUE,
    summaryFunction = caret::twoClassSummary,
    savePredictions = "final",
    sampling = sampling,
    verboseIter = TRUE,
    seeds = create_xgboost_seeds(n_folds, n_repeats)
  )

  # Parallel setup
  if (parallel) {
    if (is.null(n_cores)) {
      n_cores <- min(parallel::detectCores() - 1, 8)
    }
    message(sprintf("Enabling parallel processing: %d cores", n_cores))
    cl <- parallel::makePSOCKcluster(n_cores)
    doParallel::registerDoParallel(cl)
  }

  # Define models
  models <- list(
    "LDA" = list(method = "lda", control = regular_control),
    "CART" = list(method = "rpart", control = regular_control),
    "Random Forest" = list(method = "rf", ntree = 100, control = regular_control),
    "GBM" = list(method = "gbm", verbose = FALSE, control = regular_control),
    "Naive Bayes" = list(method = "naive_bayes", control = regular_control),
    "SVM" = list(method = "svmRadial", control = regular_control),
    "KNN" = list(method = "knn", control = regular_control),
    "Logistic Regression" = list(method = "glm", control = regular_control)
  )

  tryCatch({
    models[["NNET"]] <- list(method = "nnet", trace = FALSE, MaxNWts = 1000, control = regular_control)
  }, error = function(e) message("NNET initialization failed, skipping."))

  tryCatch({
    models[["XGBoost"]] <- list(method = "xgbTree", nthread = 1, verbosity = 0, control = xgboost_control)
  }, error = function(e) message("XGBoost initialization failed, skipping."))

  # Preprocessing setup
  pre_methods <- c()
  if (center) pre_methods <- c(pre_methods, "center")
  if (scale) pre_methods <- c(pre_methods, "scale")

  # Training loop
  trained_models <- list()
  pb <- txtProgressBar(min = 0, max = length(models), style = 3)
  cat("\nStarting training...\n")

  for (i in seq_along(models)) {
    model_name <- names(models)[i]
    cat(sprintf("\nTraining model: %s (%d/%d)\n", model_name, i, length(models)))
    model_spec <- models[[model_name]]
    set.seed(seed + i)

    train_args <- list(
      x = trainData_processed[, feature_cols, drop = FALSE],
      y = trainData_processed$Label,
      method = model_spec$method,
      trControl = model_spec$control,
      metric = "ROC"
    )

    if (length(pre_methods) > 0) {
      train_args$preProcess <- pre_methods
    }

    extra_params <- setdiff(names(model_spec), c("method", "control"))
    for (param in extra_params) {
      train_args[[param]] <- model_spec[[param]]
    }

    tryCatch({
      model <- do.call(caret::train, train_args)
      trained_models[[model_name]] <- model
      cat("Completed\n")
    }, error = function(e) {
      cat(sprintf("ailed: %s\n", e$message))
    })

    setTxtProgressBar(pb, i)
  }

  close(pb)
  if (parallel && exists("cl")) stopCluster(cl)

  return(trained_models)
}
