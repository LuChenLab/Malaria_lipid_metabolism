#' Impute missing values in feature data with a label column
#'
#' This function imputes missing values in a dataset containing a 'Label' column and multiple numeric feature columns.
#' It supports two imputation methods: **median** and **KNN**. The function ensures that the 'Label' column is excluded
#' from imputation and remains intact. Median imputation replaces missing values with the median of the respective
#' feature column, while KNN imputation estimates missing values based on the nearest neighbors of the feature columns.
#'
#' The function is particularly useful for datasets where only feature columns contain missing values, and a label column
#' needs to be preserved for further analysis or modeling. The imputation methods provided allow flexibility depending on the
#' nature of the data and the intended analysis.
#'
#' @details
#' This function provides two imputation methods:
#' - **Median imputation**: Suitable for data with a relatively small amount of missing data, where the median of each feature
#'   column is a good estimate for missing values.
#' - **KNN imputation**: This method estimates missing values based on the similarity (distance) between rows in the feature space.
#'   It is more suitable for datasets where relationships between features might help predict the missing values.
#'
#' All feature columns must be numeric. If your data contains categorical variables (e.g., `factor` or `character` types), you should
#' manually convert them to numeric format before using this function. Common approaches include one-hot encoding, label encoding, or
#' embedding depending on downstream model requirements.
#'
#' The function uses the **VIM** package for KNN imputation. If the package is not installed, an error message will prompt the user
#' to install it.
#'
#' @param data A data.frame or data.table containing a 'Label' column and numeric feature columns.
#'             The 'Label' column must not contain missing values, as it is excluded from the imputation process.
#' @param method Imputation method. Options are:
#'               - "median" (default): Replaces missing values with the median of each feature column.
#'               - "knn": Replaces missing values using the K-Nearest Neighbors (KNN) algorithm.
#' @param knn_k Integer. The number of nearest neighbors to use for KNN imputation (used only when method = "knn").
#'              Default is 5.
#'
#' @return A data.table with imputed feature values and the intact 'Label' column. The result has no missing values
#'         in the feature columns.
#'
#' @examples
#' # Simulate example data with Label column
#' dt <- data.table::data.table(
#'   Label = c(1, 0, 1),
#'   Score1 = c(1.2, NA, 2.5),
#'   Score2 = c(NA, 3.1, 2.9)
#' )
#'
#' # Median imputation
#' dt_median <- Impute_with_label(dt, method = "median")
#'
#' # KNN imputation (requires VIM)
#' \dontrun{
#' dt_knn <- Impute_with_label(dt, method = "knn", knn_k = 5)
#' }
#'
#' @seealso \code{\link[VIM]{kNN}} for details on the KNN imputation method.
#'
#' @export
Impute_with_label <- function(data, method = c("median", "knn"), knn_k = 5) {
  method <- match.arg(method)

  # Convert to data.table if needed
  if (!data.table::is.data.table(data)) {
    data <- data.table::as.data.table(data)
  }

  # Check for Label column
  if (!"Label" %in% colnames(data)) {
    stop("Input data must contain a 'Label' column.")
  }

  # Check that all other columns are numeric
  feature_cols <- setdiff(colnames(data), "Label")
  if (!all(sapply(data[, ..feature_cols], is.numeric))) {
    stop("All feature columns (excluding 'Label') must be numeric.")
  }

  if (method == "median") {
    # Median imputation for feature columns only
    data[, (feature_cols) := lapply(.SD, function(x) {
      x[is.na(x)] <- median(x, na.rm = TRUE)
      return(x)
    }), .SDcols = feature_cols]

  } else if (method == "knn") {
    if (!requireNamespace("VIM", quietly = TRUE)) {
      stop("Package 'VIM' is required for KNN imputation. Please install it.")
    }

    # Separate label and features
    label_vec <- data$Label
    feature_df <- as.data.frame(data[, ..feature_cols])

    # Apply KNN imputation
    imputed_df <- VIM::kNN(feature_df, k = knn_k, imp_var = FALSE)

    # Combine back with label
    data <- data.table::data.table(Label = label_vec, imputed_df)
  }

  # Final check
  stopifnot(!anyNA(data))
  return(data)
}
