#' Evaluate Trained Models on Independent Test Data
#'
#' This function evaluates a list of trained classification models on a held-out test set.
#' It calculates performance metrics including AUC, AUPRC, F1-score, Matthews Correlation Coefficient (MCC),
#' accuracy, sensitivity, and specificity. ROC and precision-recall curves are also returned.
#'
#' Special handling is included for models like SVM that may lack class probability predictions.
#'
#' @details
#' This function evaluates model generalization performance on an independent test set, not during training.
#' It is intended to follow \code{evaluate_train_performance()}, providing an external validation
#' of model quality based on the true generalization ability.
#'
#' The function supports models without native probability outputs (e.g., SVMs) through approximated
#' probability handling, ensuring consistent metric computation.
#'
#' @param trained_models A named list of models trained via \code{Train_multiple_models()}.
#' @param prepared_data A list returned from \code{Prepare_classification_data()},
#'                      which contains the test set (\code{testData}) and optionally training data.
#' @param seed Integer. Random seed for reproducibility (default = 123).
#'
#' @return A list with:
#' \describe{
#'   \item{test_results}{A data.frame summarizing test set evaluation metrics for each model.}
#'   \item{roc_curves}{A list of ROC curve objects (\code{pROC::roc}) for each model.}
#'   \item{pr_curves}{A list of PR curve objects (\code{PRROC::pr.curve}) for each model.}
#' }
#'
#' @examples
#' \dontrun{
#' prep <- Prepare_classification_data(my_data)
#' models <- Train_multiple_models(prep)
#' test_eval <- Evaluate_test_performance(models, prep)
#' print(test_eval$test_results)
#' }
#'
#' @seealso \code{\link[pROC]{roc}}, \code{\link[PRROC]{pr.curve}}, \code{\link[caret]{confusionMatrix}}
#'
#' @export
Evaluate_test_performance <- function(trained_models, prepared_data, seed = 123) {
  set.seed(seed)

  testData_processed <- prepared_data$testData
  test_results_summary <- data.frame()
  roc_curves <- list()
  pr_curves <- list()

  for (model_name in names(trained_models)) {
    model <- trained_models[[model_name]]

    tryCatch({
      # Special handling for SVM: ensure numeric input
      if (model_name == "SVM") {
        test_features <- testData_processed[, -which(names(testData_processed) == "Label"), drop = FALSE]
        for (col in names(test_features)) {
          test_features[[col]] <- as.numeric(as.character(test_features[[col]]))
          if (any(is.na(test_features[[col]]))) {
            fill_value <- mean(test_features[[col]], na.rm = TRUE)
            test_features[[col]][is.na(test_features[[col]])] <- fill_value
          }
        }
        if (!is.null(model$xNames)) {
          model_vars <- model$xNames
          missing_cols <- setdiff(model_vars, names(test_features))
          if (length(missing_cols) > 0) {
            for (col in missing_cols) {
              test_features[[col]] <- 0
            }
          }
          test_features <- test_features[, model_vars, drop = FALSE]
        }
        pred_class <- predict(model, newdata = test_features)
      } else {
        pred_probs <- predict(model, newdata = testData_processed, type = "prob")
        pred_class <- predict(model, newdata = testData_processed)
      }

      cm <- caret::confusionMatrix(pred_class, testData_processed$Label, positive = "pos", mode = "everything")

      if (model_name == "SVM") {
        pred_probs <- matrix(0, nrow = nrow(testData_processed), ncol = 2)
        colnames(pred_probs) <- c("neg", "pos")
        pred_probs[pred_class == "pos", "pos"] <- 0.9
        pred_probs[pred_class == "neg", "pos"] <- 0.1
      }

      tp <- cm$table["pos", "pos"]
      tn <- cm$table["neg", "neg"]
      fp <- cm$table["neg", "pos"]
      fn <- cm$table["pos", "neg"]
      denominator <- sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
      mcc_test <- ifelse(denominator == 0, NA, ((tp * tn) - (fp * fn)) / denominator)

      roc_obj <- pROC::roc(testData_processed$Label, pred_probs[, "pos"], quiet = TRUE)
      pos_probs <- pred_probs[testData_processed$Label == "pos", "pos"]
      neg_probs <- pred_probs[testData_processed$Label == "neg", "pos"]

      pr_obj <- if (length(pos_probs) > 0 && length(neg_probs) > 0) {
        PRROC::pr.curve(scores.class0 = pos_probs, scores.class1 = neg_probs, curve = TRUE)
      } else {
        list(auc.integral = NA)
      }

      auc_ci <- pROC::ci.auc(roc_obj)
      f1_test <- cm$byClass["F1"]

      roc_curves[[model_name]] <- roc_obj
      pr_curves[[model_name]] <- pr_obj

      test_results_summary <- rbind(test_results_summary, data.frame(
        Model = model_name,
        AUC = sprintf("%.3f", pROC::auc(roc_obj)),
        AUC_CI = sprintf("[%.3f–%.3f]", auc_ci[1], auc_ci[3]),
        AUPRC = sprintf("%.3f", pr_obj$auc.integral),
        F1 = sprintf("%.3f", f1_test),
        MCC = sprintf("%.3f", mcc_test),
        Accuracy = sprintf("%.3f", cm$overall["Accuracy"]),
        Sensitivity = sprintf("%.3f", cm$byClass["Sensitivity"]),
        Specificity = sprintf("%.3f", cm$byClass["Specificity"]),
        AUC_Value = pROC::auc(roc_obj),
        stringsAsFactors = FALSE
      ))
    }, error = function(e) {
      # Fallback SVM baseline
      if (model_name == "SVM") {
        pos_ratio <- mean(prepared_data$trainData$Label == "pos")
        n_samples <- nrow(testData_processed)
        pred_class <- factor(rep("neg", n_samples), levels = c("neg", "pos"))
        pos_indices <- sample(1:n_samples, round(n_samples * pos_ratio))
        pred_class[pos_indices] <- "pos"

        cm <- caret::confusionMatrix(pred_class, testData_processed$Label, positive = "pos", mode = "everything")

        tp <- cm$table["pos", "pos"]
        tn <- cm$table["neg", "neg"]
        fp <- cm$table["neg", "pos"]
        fn <- cm$table["pos", "neg"]
        denominator <- sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
        mcc_test <- ifelse(denominator == 0, NA, ((tp * tn) - (fp * fn)) / denominator)

        pred_probs <- matrix(0, nrow = n_samples, ncol = 2)
        colnames(pred_probs) <- c("neg", "pos")
        pred_probs[pred_class == "pos", "pos"] <- 0.9
        pred_probs[pred_class == "neg", "pos"] <- 0.1

        roc_obj <- pROC::roc(testData_processed$Label, pred_probs[, "pos"], quiet = TRUE)
        auc_ci <- pROC::ci.auc(roc_obj)
        f1_test <- cm$byClass["F1"]

        roc_curves[[model_name]] <- roc_obj

        test_results_summary <- rbind(test_results_summary, data.frame(
          Model = paste0(model_name, " (baseline)"),
          AUC = sprintf("%.3f", pROC::auc(roc_obj)),
          AUC_CI = sprintf("[%.3f–%.3f]", auc_ci[1], auc_ci[3]),
          AUPRC = "NA",
          F1 = sprintf("%.3f", f1_test),
          MCC = sprintf("%.3f", mcc_test),
          Accuracy = sprintf("%.3f", cm$overall["Accuracy"]),
          Sensitivity = sprintf("%.3f", cm$byClass["Sensitivity"]),
          Specificity = sprintf("%.3f", cm$byClass["Specificity"]),
          AUC_Value = pROC::auc(roc_obj),
          stringsAsFactors = FALSE
        ))
      }
    })
  }

  if (nrow(test_results_summary) == 0) {
    warning("No models were successfully evaluated on test set")
    return(NULL)
  }

  test_results_summary <- test_results_summary[order(test_results_summary$AUC_Value, decreasing = TRUE), ]
  test_results_summary$AUC_Value <- NULL

  cat("\nTest Set Model Performance Ranking (by AUC):\n")
  for (i in seq_len(nrow(test_results_summary))) {
    cat(sprintf("%d. %s: AUC=%s, AUPRC=%s, F1=%s, MCC=%s\n",
                i,
                test_results_summary$Model[i],
                test_results_summary$AUC[i],
                test_results_summary$AUPRC[i],
                test_results_summary$F1[i],
                test_results_summary$MCC[i]))
  }

  return(list(
    test_results = test_results_summary,
    roc_curves = roc_curves,
    pr_curves = pr_curves
  ))
}
