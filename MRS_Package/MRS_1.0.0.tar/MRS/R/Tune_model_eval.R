#' Hyperparameter Tuning and Evaluation for a Selected Classification Model
#'
#' This function tunes and evaluates a selected machine learning model using the \code{caret} framework.
#' It supports both default and custom tuning grids, repeated cross-validation, and parallel computation.
#'
#' The function reports performance metrics including AUC, AUPRC, F1-score, and MCC on cross-validation folds,
#' full training data, and an independent test set. It also extracts feature importance if supported by the model.
#'
#' @details
#' This function supports automatic tuning via a default grid or random search. Custom tuning grids can be passed
#' via the \code{custom_grid} argument. Performance metrics are calculated using internal predictions from \code{caret::train()},
#' as well as predictions on the full training and test sets.
#'
#' Feature importance is extracted when supported by the selected model type (e.g., \code{rf}, \code{xgbTree}, \code{glm}).
#'
#' The function can accept data prepared by \code{Prepare_classification_data()} directly or the result of
#' optional feature selection from \code{Feature_selection_ablation()}, which returns reduced \code{trainData} and \code{testData}.
#'
#' @param model_name The model to train (e.g., \code{"XGBoost"}, \code{"Random Forest"}, \code{"SVM"}).
#' @param prepared_data A list returned from \code{Prepare_classification_data()}, or optionally from \code{Feature_selection_ablation()}.
#' @param n_folds Number of cross-validation folds (default: 10).
#' @param n_repeats Number of cross-validation repeats (default: 1).
#' @param seed Random seed for reproducibility (default: 123).
#' @param parallel Logical. Whether to enable parallel training (default: FALSE).
#' @param n_cores Number of cores to use in parallel (default: all available - 1).
#' @param tune_length Integer. Number of random tuning combinations (if no custom grid is supplied).
#' @param custom_grid Optional custom grid as a \code{data.frame} for hyperparameter tuning.
#' @param sampling Resampling strategy (e.g., \code{"up"}, \code{"down"}, \code{"smote"}, or \code{NULL}).
#' @param center Logical. Whether to apply centering during preprocessing.
#' @param scale Logical. Whether to apply scaling during preprocessing.
#' @param search Search method: \code{"grid"} (default) or \code{"random"}.
#'
#' @return A list containing:
#' \describe{
#'   \item{best_model}{Trained \code{caret} model with the best hyperparameter configuration.}
#'   \item{train_metrics}{Per-fold metrics from cross-validation.}
#'   \item{final_train_metrics}{Aggregated metrics on the entire training set.}
#'   \item{final_test_metrics}{Aggregated metrics on the test set.}
#'   \item{train_roc_list}{ROC objects per fold (training).}
#'   \item{train_pr_list}{PR curve objects per fold (training).}
#'   \item{train_roc}{ROC curve on the full training set.}
#'   \item{train_pr}{PR curve on the full training set.}
#'   \item{test_roc}{ROC curve on the test set.}
#'   \item{test_pr}{PR curve on the test set.}
#'   \item{feature_importance}{Ranked feature importance (if supported by model).}
#' }
#'
#' @examples
#' \dontrun{
#' # Option 1: Use classification-ready data directly
#' data_split <- Prepare_classification_data(data)
#' tuned_result <- Tune_model_eval(
#'   model_name = "XGBoost",
#'   prepared_data = data_split,
#'   n_folds = 5,
#'   parallel = TRUE,
#'   n_cores = 4
#' )
#'
#' # Option 2: Use feature-selected data from ablation (optional step)
#' data_split <- Prepare_classification_data(data)
#' data_split <- Feature_selection_ablation(data_split, model_name = "XGBoost")
#' tuned_result <- Tune_model_eval(
#'   model_name = "XGBoost",
#'   prepared_data = data_split,
#'   n_folds = 5,
#'   parallel = TRUE,
#'   n_cores = 4
#' )
#'
#' print(tuned_result$final_test_metrics)
#' head(tuned_result$feature_importance)
#' }
#'
#' @seealso \code{\link[caret]{train}}, \code{\link[caret]{trainControl}},
#'   \code{\link[pROC]{roc}}, \code{\link[PRROC]{pr.curve}}, \code{\link[caret]{varImp}}
#'
#' @export
Tune_model_eval <- function(model_name, prepared_data,
                            n_folds = 10, n_repeats = 1,
                            seed = 123, parallel = FALSE,
                            n_cores = NULL, tune_length = 100,
                            custom_grid = NULL, sampling = "up",
                            center = TRUE, scale = TRUE,
                            search = "grid") {
  set.seed(seed)

  model_map <- list(
    "LDA" = "lda",
    "CART" = "rpart",
    "Random Forest" = "rf",
    "GBM" = "gbm",
    "Naive Bayes" = "naive_bayes",
    "SVM" = "svmRadial",
    "KNN" = "knn",
    "Logistic Regression" = "glm",
    "NNET" = "nnet",
    "XGBoost" = "xgbTree"
  )

  if (model_name %in% names(model_map)) {
    caret_method <- model_map[[model_name]]
  } else if (model_name %in% unlist(model_map)) {
    caret_method <- model_name
  } else {
    stop("Unsupported model_name. Choose from: ",
         paste(names(model_map), collapse = ", "))
  }

  train_data <- prepared_data$trainData
  test_data <- prepared_data$testData

  if (parallel) {
    if (is.null(n_cores)) {
      n_cores <- parallel::detectCores() - 1
    }
    cl <- parallel::makePSOCKcluster(n_cores)
    doParallel::registerDoParallel(cl)
    cat(sprintf("Parallel enabled: %d cores\n", n_cores))
  }

  customSummary <- function(data, lev = NULL, model = NULL) {
    auc_val <- tryCatch({
      roc_obj <- pROC::roc(data$obs, data$pos, quiet = TRUE)
      as.numeric(pROC::auc(roc_obj))
    }, error = function(e) NA)

    auprc_val <- tryCatch({
      pr_obj <- PRROC::pr.curve(
        scores.class0 = data$pos[data$obs == "pos"],
        scores.class1 = data$pos[data$obs == "neg"],
        curve = FALSE
      )
      pr_obj$auc.integral
    }, error = function(e) NA)

    f1_val <- tryCatch({
      cm <- caret::confusionMatrix(data$pred, data$obs, positive = "pos")
      cm$byClass["F1"]
    }, error = function(e) NA)

    mcc_val <- tryCatch({
      cm <- caret::confusionMatrix(data$pred, data$obs, positive = "pos")
      TP <- cm$table["pos", "pos"]
      TN <- cm$table["neg", "neg"]
      FP <- cm$table["pos", "neg"]
      FN <- cm$table["neg", "pos"]
      denom <- (TP + FP) * (TP + FN) * (TN + FP) * (TN + FN)
      if (denom == 0) 0 else ((TP * TN) - (FP * FN)) / sqrt(denom)
    }, error = function(e) NA)

    c(AUC = auc_val, AUPRC = auprc_val, F1 = f1_val, MCC = mcc_val)
  }

  ctrl <- caret::trainControl(
    method = "repeatedcv",
    number = n_folds,
    repeats = n_repeats,
    classProbs = TRUE,
    summaryFunction = customSummary,
    savePredictions = "final",
    verboseIter = FALSE,
    sampling = sampling,
    search = search
  )

  num_features <- ncol(train_data) - 1
  default_grids <- list(
    rf = expand.grid(mtry = seq(2, min(20, num_features), by = 2)),
    gbm = expand.grid(
      interaction.depth = c(3, 6, 9),
      n.trees = c(200, 400, 600),
      shrinkage = c(0.01, 0.05),
      n.minobsinnode = c(5, 10)
    ),
    svmRadial = expand.grid(sigma = c(0.001, 0.01, 0.05), C = c(0.1, 1, 5, 10, 20)),
    knn = expand.grid(k = seq(3, 25, by = 2)),
    nnet = expand.grid(size = c(5, 10, 15), decay = c(0.01, 0.1, 0.5)),
    xgbTree = expand.grid(
      nrounds = c(200, 300, 500),
      max_depth = c(6, 9, 12),
      eta = c(0.01, 0.05),
      gamma = c(0, 1),
      colsample_bytree = c(0.8, 1.0),
      min_child_weight = c(1, 3),
      subsample = c(0.8, 1.0)
    )
  )

  pre_methods <- c()
  if (center) pre_methods <- c(pre_methods, "center")
  if (scale) pre_methods <- c(pre_methods, "scale")

  model_args <- list(
    x = train_data[, -which(names(train_data) == "Label"), drop = FALSE],
    y = train_data$Label,
    method = caret_method,
    trControl = ctrl,
    metric = "AUC",
    preProcess = pre_methods
  )

  if (caret_method == "xgbTree") model_args$nthread <- 1

  if (!is.null(custom_grid)) {
    model_args$tuneGrid <- custom_grid
  } else if (caret_method %in% names(default_grids)) {
    model_args$tuneGrid <- default_grids[[caret_method]]
  } else {
    model_args$tuneLength <- tune_length
  }

  cat(sprintf("Training model: %s\n", model_name))
  model <- suppressMessages(suppressWarnings(do.call(caret::train, model_args)))
  cat("Model training complete.\n")

  # Per-fold evaluation
  unique_folds <- unique(model$pred$Resample)
  train_fold_metrics <- data.frame(Fold = character(), AUC = numeric(), AUPRC = numeric(), F1 = numeric(), MCC = numeric())
  train_roc_list <- list()
  train_pr_list <- list()

  cat("Evaluating each fold on training data...\n")
  pb <- txtProgressBar(min = 0, max = length(unique_folds), style = 3)
  for (i in seq_along(unique_folds)) {
    fold <- unique_folds[i]
    fold_pred <- model$pred[model$pred$Resample == fold, ]
    pos_prob_col <- if ("pos" %in% names(fold_pred)) "pos" else names(fold_pred)[ncol(fold_pred) - 1]

    roc_train <- tryCatch(pROC::roc(fold_pred$obs, fold_pred[[pos_prob_col]], quiet = TRUE), error = function(e) NULL)
    auc_train <- if (!is.null(roc_train)) as.numeric(roc_train$auc) else NA

    pr_train <- tryCatch({
      PRROC::pr.curve(
        scores.class0 = fold_pred[[pos_prob_col]][fold_pred$obs == "pos"],
        scores.class1 = fold_pred[[pos_prob_col]][fold_pred$obs == "neg"],
        curve = TRUE
      )
    }, error = function(e) NULL)
    auprc_train <- if (!is.null(pr_train)) pr_train$auc.integral else NA

    f1_train <- tryCatch({
      cm <- caret::confusionMatrix(fold_pred$pred, fold_pred$obs, positive = "pos")
      cm$byClass["F1"]
    }, error = function(e) NA)

    mcc_train <- tryCatch({
      cm <- caret::confusionMatrix(fold_pred$pred, fold_pred$obs, positive = "pos")
      TP <- cm$table["pos", "pos"]
      TN <- cm$table["neg", "neg"]
      FP <- cm$table["pos", "neg"]
      FN <- cm$table["neg", "pos"]
      denom <- (TP + FP) * (TP + FN) * (TN + FP) * (TN + FN)
      if (denom == 0) 0 else ((TP * TN) - (FP * FN)) / sqrt(denom)
    }, error = function(e) NA)

    train_fold_metrics <- rbind(train_fold_metrics, data.frame(Fold = fold, AUC = auc_train, AUPRC = auprc_train, F1 = f1_train, MCC = mcc_train))
    train_roc_list[[fold]] <- roc_train
    train_pr_list[[fold]] <- pr_train
    setTxtProgressBar(pb, i)
  }
  close(pb)

  # Full training set evaluation
  if (caret_method == "svmRadial") {
    train_features <- train_data[, setdiff(names(train_data), "Label"), drop = FALSE]
  } else {
    train_features <- train_data
  }
  train_probs <- predict(model, newdata = train_features, type = "prob")
  train_preds <- predict(model, newdata = train_features)
  roc_full_train <- tryCatch(pROC::roc(train_data$Label, train_probs[, "pos"], quiet = TRUE), error = function(e) NULL)
  pr_full_train <- tryCatch(PRROC::pr.curve(scores.class0 = train_probs[train_data$Label == "pos", "pos"],
                                            scores.class1 = train_probs[train_data$Label == "neg", "pos"],
                                            curve = TRUE), error = function(e) NULL)
  f1_full_train <- tryCatch(caret::confusionMatrix(train_preds, train_data$Label, positive = "pos")$byClass["F1"], error = function(e) NA)
  mcc_full_train <- tryCatch({
    cm <- caret::confusionMatrix(train_preds, train_data$Label, positive = "pos")
    TP <- cm$table["pos", "pos"]
    TN <- cm$table["neg", "neg"]
    FP <- cm$table["pos", "neg"]
    FN <- cm$table["neg", "pos"]
    denom <- (TP + FP) * (TP + FN) * (TN + FP) * (TN + FN)
    if (denom == 0) 0 else ((TP * TN) - (FP * FN)) / sqrt(denom)
  }, error = function(e) NA)
  final_train_metrics <- data.frame(AUC = if (!is.null(roc_full_train)) as.numeric(roc_full_train$auc) else NA,
                                    AUPRC = if (!is.null(pr_full_train)) pr_full_train$auc.integral else NA,
                                    F1 = as.numeric(f1_full_train),
                                    MCC = as.numeric(mcc_full_train))

  # Test set evaluation
  if (caret_method == "svmRadial") {
    test_features <- test_data[, setdiff(names(test_data), "Label"), drop = FALSE]
  } else {
    test_features <- test_data
  }
  test_probs <- predict(model, newdata = test_features, type = "prob")
  test_preds <- predict(model, newdata = test_features)
  roc_test <- tryCatch(pROC::roc(test_data$Label, test_probs[, "pos"], quiet = TRUE), error = function(e) NULL)
  pr_test <- tryCatch(PRROC::pr.curve(scores.class0 = test_probs[test_data$Label == "pos", "pos"],
                                      scores.class1 = test_probs[test_data$Label == "neg", "pos"],
                                      curve = TRUE), error = function(e) NULL)
  f1_test <- tryCatch(caret::confusionMatrix(test_preds, test_data$Label, positive = "pos")$byClass["F1"], error = function(e) NA)
  mcc_test <- tryCatch({
    cm <- caret::confusionMatrix(test_preds, test_data$Label, positive = "pos")
    TP <- cm$table["pos", "pos"]
    TN <- cm$table["neg", "neg"]
    FP <- cm$table["pos", "neg"]
    FN <- cm$table["neg", "pos"]
    denom <- (TP + FP) * (TP + FN) * (TN + FP) * (TN + FN)
    if (denom == 0) 0 else ((TP * TN) - (FP * FN)) / sqrt(denom)
  }, error = function(e) NA)
  final_test_metrics <- data.frame(AUC = if (!is.null(roc_test)) as.numeric(roc_test$auc) else NA,
                                   AUPRC = if (!is.null(pr_test)) pr_test$auc.integral else NA,
                                   F1 = as.numeric(f1_test),
                                   MCC = as.numeric(mcc_test))

  # Feature importance
  supported_models <- c("rf", "xgbTree", "gbm", "glm", "svmRadial", "nnet")
  feature_importance <- NULL
  if (caret_method %in% supported_models) {
    tryCatch({
      importance_obj <- caret::varImp(model, scale = TRUE)
      importance_df <- importance_obj$importance
      importance_df$Feature <- rownames(importance_df)
      rownames(importance_df) <- NULL
      feature_importance <- importance_df[order(-importance_df$Overall), ]
    }, error = function(e) {
      cat("Warning: Feature importance extraction failed.\n")
    })
  }

  if (parallel && exists("cl")) {
    parallel::stopCluster(cl)
    cat("Parallel cluster stopped.\n")
  }

  return(list(
    best_model = model,
    train_metrics = train_fold_metrics,
    final_train_metrics = final_train_metrics,
    final_test_metrics = final_test_metrics,
    train_roc_list = train_roc_list,
    train_pr_list = train_pr_list,
    train_roc = roc_full_train,
    train_pr = pr_full_train,
    test_roc = roc_test,
    test_pr = pr_test,
    feature_importance = feature_importance
  ))
}

